#pragma once

#define SERIAL_BAUD 115200
#define I2C_FREQ 400000
#define CAN_BAUDRATE 500000
#define SAMPLE_RATE_HZ 1000

#define I2C_SDA_PIN 15
#define I2C_SCL_PIN 16
#define CAN_TX_PIN 4
#define CAN_RX_PIN 5

#define INNER_AS5600_ADDR 0x36
#define ODRV0_NODE_ID 0

#define PULLEY_RADIUS_M 0.01f
#define PULLEY_CIRCUMFERENCE_M (PULLEY_RADIUS_M * PI * 2.0f)
