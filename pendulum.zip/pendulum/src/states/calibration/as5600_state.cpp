#include "src/states/calibration/as5600_state.h"

#include <Arduino.h>
#include <Wire.h>
#include <cstdint>

#include "src/utils/as5600.h"
#include "src/utils/log_macros.h"

constexpr float STABILITY_DURATION_US = 5'000'000.0;
constexpr float LOW_PASS_ALPHA = 0.5;
constexpr float VELOCITY_THRESHOLD = 0.4; // rad/s

SequenceStatus as5600_calibration(AS5600CalibrationResult *result) {

	static unsigned long last_sample_time = micros();
	unsigned long t = micros();
	unsigned long dt = t - last_sample_time;

	if (dt < 100000) {
		return SequenceStatus::RUNNING;
	}

	last_sample_time = t;

	static float angle_rad = 0;
	static float angle_rad_prev = 0;
	static float cos_angle = 0, cos_angle_prev = 0;
	static float sin_angle = 0, sin_angle_prev = 0;
	static float angular_vel_filtered = 0;

	static float avg_raw_angle = 0;
	static int avg_sample_count = 0;

	static unsigned long stable_since_us = 0;

	int16_t raw_angle = as5600_read_raw();
	if (raw_angle == -1) {
		LOOP_ERROR("[CALIBRATION] [AS5600] raw_angle read failed");
		return SequenceStatus::ERROR;
	}

	angle_rad_prev = angle_rad;
	angle_rad = raw_angle * (2.0 * PI / 4096.0);

	cos_angle_prev = cos_angle;
	sin_angle_prev = sin_angle;
	cos_angle = cos(angle_rad);
	sin_angle = sin(angle_rad);

	float dt_s = dt / 1'000'000.0;
	float angular_vel = ((sin_angle - sin_angle_prev) * cos_angle - (cos_angle - cos_angle_prev) * sin_angle) / dt_s;

	LOOP_LOG("[CALIBRATION] [AS5600] raw_angle : %i, angular_vel: %.2f, cos: %.2f, sin: %.2f", raw_angle, angular_vel,
	         cos_angle, sin_angle);

	bool is_stable = abs(angular_vel) < VELOCITY_THRESHOLD;
	if (!is_stable) {
		stable_since_us = t;
		avg_sample_count = 0;
		avg_raw_angle = 0;
	} else {
		if (stable_since_us == 0)
			stable_since_us = t;

		avg_sample_count++;
		avg_raw_angle += (raw_angle - avg_raw_angle) / avg_sample_count;

		if (t - stable_since_us >= STABILITY_DURATION_US) {
			result->raw_offset = avg_raw_angle;

			LOOP_LOG("[CALIBRATION] [AS5600] offset set to %.4f", avg_raw_angle);
			return SequenceStatus::DONE;
		}
	}

	return SequenceStatus::RUNNING;
}
